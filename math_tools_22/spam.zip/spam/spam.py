import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import AdaBoostClassifier


# Preprocess: split the dataset in a training set and a testing set
def split(data, p=0.5):
    N = data.shape[0]
    n_train = int(0.5 * N)
    n_test = N - n_train
    idx = np.random.randint(N, size=n_train)

    data_train = data[idx, :]
    data_test = data[~idx, :]
    return data_train, data_test


def main():
    # The spambase dataset contains 57 continuous features describing an email.
    # Those features record the frequences of certain given words, the number of capital letters in the email, etc.
    # The last column is 0 (not a spam) or 1 (a spam)

    data = np.genfromtxt('spambase.csv', delimiter=',')
    N = data.shape[0]  # Total number of observations
    d = data.shape[1] - 1  # Number of features
    
    data_train, data_test = split(data)
    
    
if __name__ == "__main__":
    main()
